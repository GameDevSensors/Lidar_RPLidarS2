# Quick Start Guides

## YDLidar-SDK 1.0.0

- [YDLidar-SDK 1.0.0 quick start](ydlidar_sdk_1_0_0_quick_start.md)
- [YDLidar-SDK 1.0.0 quick start cn](ydlidar_sdk_1_0_0_quick_start_cn.md)
- [YDLidar-SDK 1.0.0 hardware system installation guide](ydlidar_sdk_1_0_0_hardware_system_installation_guide.md)
- [YDLidar-SDK 1.0.0 quick start developer](ydlidar_sdk_1_0_0_quick_start_developer.md)

## Others
- [YDLidar-SDK software installation guide](ydlidar_sdk_software_installation_guide.md)

