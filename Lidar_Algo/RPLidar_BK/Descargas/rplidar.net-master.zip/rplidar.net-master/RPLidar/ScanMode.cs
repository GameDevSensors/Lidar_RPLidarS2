﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPLidar
{
    /// <summary>
    /// Scan mode
    /// </summary>
    public enum ScanMode
    {
        Legacy,
        ExpressLegacy,
        ExpressExtended
    }
}
